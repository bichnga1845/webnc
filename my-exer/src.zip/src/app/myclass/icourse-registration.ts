export interface ICourseRegistration {
  studentName: string;
  email: string;
  phone: string;
  course: string;
  semester: string;
  gender: string;
  address: string;
}
