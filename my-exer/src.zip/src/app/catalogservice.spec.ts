import { TestBed } from '@angular/core/testing';

import { CatalogService } from './catalogservice';

describe('Catalogservice', () => {
  let service: CatalogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CatalogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
