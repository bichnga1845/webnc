import { Component } from '@angular/core';

@Component({
  selector: 'app-notfound',
  standalone: false,
  templateUrl: './notfound.html',
  styleUrl: './notfound.css',
})
export class Notfound {

}
